def classFactory(iface):
    from .arch_distribution import ArchDistribution
    return ArchDistribution(iface)
